package aula28.pkg08java;

import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author ifg
 */
public class TelaCadastro extends javax.swing.JFrame {

    /**
     * Creates new form TelaCadastro
     */
    private Usuario user;
    
    public TelaCadastro() {
        initComponents();
        setLocationRelativeTo(null);
    }
   
    public TelaCadastro(Usuario us) {
        this.user = us; //setando usuario do parametro ao atributo
        initComponents();
        setLocationRelativeTo(null);
        this.textNoime.setText(this.user.getNome());
        this.textEmail.setText(this.user.getEmail());
        this.textCidade.setText(this.user.getCidade());
        this.jPasswordField1.setText(this.user.getSenha());
        this.jPasswordField2.setText(this.user.getSenha());
        if(this.textEmail.equals(" ")) {
            this.textEmail.setEnabled(true);
        }
        else {
            this.textEmail.setEnabled(false);
        }
        
    }
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        BotaoRegistrar = new javax.swing.JButton();
        textNoime = new javax.swing.JTextField();
        textCidade = new javax.swing.JTextField();
        textEmail = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        jPasswordField2 = new javax.swing.JPasswordField();
        BotaoCancelarRegistro = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Nome Completo:");

        jLabel2.setText("Cidade / Estado:");

        jLabel3.setText("Email:");

        jLabel4.setText("Senha:");

        jLabel5.setText("Repita a senha:");

        BotaoRegistrar.setText("Registrar");
        BotaoRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoRegistrarActionPerformed(evt);
            }
        });

        BotaoCancelarRegistro.setText("Cancelar Registro");
        BotaoCancelarRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoCancelarRegistroActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel5)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textNoime)
                            .addComponent(textCidade)
                            .addComponent(textEmail)
                            .addComponent(jPasswordField1)
                            .addComponent(jPasswordField2)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(BotaoRegistrar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 266, Short.MAX_VALUE)
                        .addComponent(BotaoCancelarRegistro)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(textNoime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(textCidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(textEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jPasswordField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BotaoRegistrar)
                    .addComponent(BotaoCancelarRegistro))
                .addContainerGap(41, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BotaoRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoRegistrarActionPerformed
        //Realizaçao do cadastro no banco de dados
        String confere = new String(jPasswordField1.getPassword());
        String conf = new String(jPasswordField2.getPassword());

        if (confere.equals(conf)) {
            ConexaoDataBase conDt = new ConexaoDataBase(this.user);
            conDt.conectar();
            try {
                if(user == null){ //se o usuario for nulo, faz o cadastro
                     conDt.conectarCadastro( textEmail.getText(), textNoime.getText(), textCidade.getText(), new String(jPasswordField1.getPassword()));
                 JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso");
                 user = conDt.Login(textEmail.getText(), new String(jPasswordField1.getPassword()));
                 TelaPrincipal tlp = new TelaPrincipal(this.user);
                 tlp.setVisible(true);
                 dispose();
                    
                } else{ //se estiver preeenchido, realiza a alteracao 
                    user = conDt.alterar(textNoime.getText(), textCidade.getText(), new String(jPasswordField1.getPassword()), this.user.getEmail(), this.user.getId());
                    JOptionPane.showMessageDialog(null, "Alteração realizada com sucesso"); 
                    TelaPrincipal tlp = new TelaPrincipal(this.user);
                    tlp.setVisible(true);
                    dispose();
                }
               
            } catch (SQLException e) { 
                JOptionPane.showMessageDialog(null, "Cadastro nao efetuado, ocorreu algum erro");
               e.printStackTrace();  //verificar qual e o erro
            }

        } else {
            JOptionPane.showMessageDialog(null, "Senhas nao correspondem a mesma digitada na primeira vez!!");
        } 


    }//GEN-LAST:event_BotaoRegistrarActionPerformed

    private void BotaoCancelarRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoCancelarRegistroActionPerformed
        // TODO add your handling code here:
        if(user==null){ //Se caso quem estiver na TelaCadastro não estiver alterando e sim realizando cadastro e cancelar
        Inicial Tl2 = new Inicial();   //sera mandado a tela Inicial
        Tl2.setVisible(true);
        dispose();
        } else{ //Mas se os campos de textos estiverem preenchidos conforme alteração, este sera encaminhado a TelaPrincipal
            TelaPrincipal tlp = new TelaPrincipal(this.user);
            tlp.setVisible(true); 
            dispose();
        }
    }//GEN-LAST:event_BotaoCancelarRegistroActionPerformed

    /**
     * @param args the command line arguments
     */
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotaoCancelarRegistro;
    private javax.swing.JButton BotaoRegistrar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JPasswordField jPasswordField2;
    private javax.swing.JTextField textCidade;
    private javax.swing.JTextField textEmail;
    private javax.swing.JTextField textNoime;
    // End of variables declaration//GEN-END:variables
}

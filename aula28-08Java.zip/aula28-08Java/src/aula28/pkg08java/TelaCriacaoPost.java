package aula28.pkg08java;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class TelaCriacaoPost extends javax.swing.JFrame {

    //objeto do tipo usuario que vem por parametro ao chamar esssa tela
    private Usuario us;
    //objeto de tipo FileChoser, atraves do FileChooser conseguimos obter um arquivo do disco rígido
    private JFileChooser escolheImagem;
    private ConexaoDataBase conn;
    //objeto que ficará responsável por guardar as informações do arquivo, tamanho, tipo, ...
    private File arquivo;

    public TelaCriacaoPost() {
        initComponents();
        setLocationRelativeTo(null); //Centraliza a tela no meio
    }

    public TelaCriacaoPost(Usuario us) { //O usuario esta vindo por parametro
        initComponents();
        setLocationRelativeTo(null); //Centraliza a tela no meio
        this.us = us; //setando usuario do parametro ao atributo

        escolheImagem = new JFileChooser();
        conn = new ConexaoDataBase(this.us);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextArea1 = new javax.swing.JTextArea();
        BotaoCancelarPost = new javax.swing.JButton();
        BotaoSalvarPost = new javax.swing.JButton();
        BotaoAdicionarImagem = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);

        BotaoCancelarPost.setText("CANCELAR POST");
        BotaoCancelarPost.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoCancelarPostActionPerformed(evt);
            }
        });

        BotaoSalvarPost.setText("SALVAR POST");
        BotaoSalvarPost.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoSalvarPostActionPerformed(evt);
            }
        });

        BotaoAdicionarImagem.setText("ADICIONAR IMAGEM");
        BotaoAdicionarImagem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoAdicionarImagemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(37, Short.MAX_VALUE)
                .addComponent(jTextArea1, javax.swing.GroupLayout.PREFERRED_SIZE, 482, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(BotaoAdicionarImagem)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(BotaoSalvarPost)
                .addGap(70, 70, 70)
                .addComponent(BotaoCancelarPost)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jTextArea1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BotaoCancelarPost)
                    .addComponent(BotaoSalvarPost)
                    .addComponent(BotaoAdicionarImagem))
                .addGap(77, 77, 77))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BotaoCancelarPostActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoCancelarPostActionPerformed
        // TODO add your handling code here:
        TelaPrincipal tlp = new TelaPrincipal(this.us);
        tlp.setVisible(true);
        dispose();
    }//GEN-LAST:event_BotaoCancelarPostActionPerformed

    private void BotaoSalvarPostActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoSalvarPostActionPerformed

        if (this.jTextArea1.getText().length() <= 140) {
            ConexaoDataBase conn = new ConexaoDataBase(this.us);
            if(arquivo == null){
                 conn.post(jTextArea1.getText(), this.us.getId());
            }
            else{
                conn.postComImagem(jTextArea1.getText(), arquivo, this.us.getId());
            }
            JOptionPane.showMessageDialog(null, "Salvo com sucesso");
            TelaPrincipal tp = new TelaPrincipal(this.us); 
            tp.setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(null, "Somente textos com 140 caracteres");
        }
       
    }//GEN-LAST:event_BotaoSalvarPostActionPerformed

    private void BotaoAdicionarImagemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoAdicionarImagemActionPerformed
        // TODO add your handling code here:
        if (evt.getSource() == BotaoAdicionarImagem) {
            int retorno = escolheImagem.showOpenDialog(this);
            if (retorno == JFileChooser.APPROVE_OPTION) {
                arquivo = escolheImagem.getSelectedFile();
            }
        }
    }//GEN-LAST:event_BotaoAdicionarImagemActionPerformed
    
    


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotaoAdicionarImagem;
    private javax.swing.JButton BotaoCancelarPost;
    private javax.swing.JButton BotaoSalvarPost;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}

package aula28.pkg08java;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class ConexaoDataBase {

    // string URL padrão
    // endereço: localhost
    // base de dados: mtp
    private String url = "jdbc:postgresql://localhost/pessoa";

    // usuário do postgres
    private String usuario = "postgres";

    // senha do postgres
    private String senha = "machado18";

    // variável que guarda a conexão
    private Connection conn;

    private Usuario user;

    /**
     * Método construtor.
     *
     * Toda vez que instanciar essa classe, a conexão é automaticamente feita
     */
    public ConexaoDataBase(Usuario user) {
        this.user = user; //setando usuario do parametro ao atributo
        conectar();
    }

    /**
     * Método para conexão com o banco de dados.
     *
     * Carrega o driver e cria a conexão com o BD.
     */
    public void conectar() {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }

        Properties props = new Properties();
        props.setProperty("user", this.usuario);
        props.setProperty("password", this.senha);

        try {
            this.conn = DriverManager.getConnection(this.url, props);
        } catch (SQLException e) {
            e.getMessage();
        }

    }

    /**
     * Método que retorna a conexão feita com o BD
     *
     * @return um objeto Connection que é a conexão feita com o BD
     */
    public Usuario Login(String Email, String Senha) { //Metodo Construtor
        try {
            PreparedStatement ps = this.conn.prepareStatement("SELECT id, nome, cidade_estado, email, senha FROM pessoa where email = ? AND senha = ?");
            ps.setString(1, Email);

            ps.setString(2, Senha);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {

                Usuario us = new Usuario();
                us.setId(rs.getInt(1));
                us.setNome(rs.getString(2));
                us.setCidade(rs.getString(3));
                us.setEmail(rs.getString(4));
                us.setSenha(rs.getString(5));

                return us;
            } else {
                return null;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    public void conectarCadastro(String email, String nome, String cidade, String senha) throws SQLException {
        PreparedStatement consulta = this.conn.prepareStatement("INSERT INTO public.pessoa(\n"
                + "	 nome, email, cidade_estado, senha)\n"
                + "	VALUES (?, ?, ?, ?)");
        consulta.setString(1, nome);
        consulta.setString(2, email);
        consulta.setString(3, cidade);
        consulta.setString(4, senha);
        consulta.executeUpdate();
        consulta.close();

    }

    public Usuario alterar(String nome, String cidade, String senha, String email, Integer id) { //Metodo Construtor
        Usuario user = new Usuario(); //Instaciando o usuario
        try {
            PreparedStatement st = this.conn.prepareStatement("UPDATE pessoa SET nome=?, cidade_estado=?, senha=? WHERE id = ?");
            st.setString(1, nome);
            st.setString(2, cidade);
            st.setString(3, senha);
            st.setInt(4, id);

            st.executeUpdate();
            st.close();
            //aqui ele esta atualizando o usuario, com novos dados alterados
            user.setId(id);
            user.setNome(nome);
            user.setEmail(email);
            user.setCidade(cidade);
            user.setSenha(senha);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }

    public void post(String texto, int pessoa) {
        try {

            PreparedStatement insere = this.conn.prepareStatement("INSERT INTO public.post(\n"
                    + "	texto, fk_pessoa, data)\n"
                    + "	VALUES (?, ?, now())");
            insere.setString(1, texto);
            insere.setInt(2, pessoa);
            insere.executeUpdate();
            insere.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void post(String texto, File imagem, int pessoa) {
        try {

            PreparedStatement insere = this.conn.prepareStatement("INSERT INTO public.post(\n"
                    + "	texto, imagem, fk_pessoa, data)\n"
                    + "	VALUES (?, ?, ?, now())");
            insere.setString(1, texto);

            if (imagem != null) {
                FileInputStream fis = new FileInputStream(imagem);
                insere.setBinaryStream(2, fis, (int) imagem.length());
            } else {
                insere.setBinaryStream(2, null, 0);
            }

            insere.setInt(3, pessoa);
            insere.executeUpdate();
            insere.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }

    }

    public void postComImagem(String texto, File imagem, int pessoa) {
        try {

            PreparedStatement insere = this.conn.prepareStatement("INSERT INTO public.post(\n"
                    + "	texto, imagem, fk_pessoa, data)\n"
                    + "	VALUES (?, ?, ?, now())");
            insere.setString(1, texto);

            FileInputStream fis = new FileInputStream(imagem);
            insere.setBinaryStream(2, fis, (int) imagem.length());

            insere.setInt(3, pessoa);
            insere.executeUpdate();
            insere.close();
            fis.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }catch(IOException e){
          // e.printStackTrace();
          JOptionPane.showMessageDialog(null,"erro!");
        }

    }
    
    public ArrayList<Post> buscarPost(Usuario user){ //Método Construtor
        ArrayList<Post> item = new ArrayList<>();
        try {
            PreparedStatement ps = this.conn.prepareStatement("SELECT post.id, post.texto, post.fk_pessoa, post.data, post.imagem, pessoa.nome\n" +
"FROM  post  \n" +
"join pessoa on pessoa.id = post.fk_pessoa\n" +
"WHERE fk_pessoa = ? order by id desc limit 3 ;");
            ps.setInt(1,user.getId());
           //tinha 2 linhas com  'ps.setInt(2,user.getId());' retirei esta e deixei a outra acima e funcionou
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){ //AQUI ESTA FAZENDO A VARREDURA
                Post pos = new Post();
                pos.setId(rs.getInt(1));
                pos.setImagem(rs.getBytes(5));
                pos.setPessoa(rs.getInt(3));
                pos.setTexto(rs.getString(2));
                pos.setData(rs.getDate(4));
                pos.setNome(rs.getString(6));
              //  CriarPost post = new CriarPost();
                item.add(pos);
                
                
            }
             return item;// faz a operação, ou seja, pega os 3 post e encerra, SE CASO O 'RETURN' FICASSE EM CIMA ELE 
        } catch (SQLException ex) {       //FARIA A PRIMEIRA OPERAÇÃO E ENCERRAVA SEM ANTES CONCLUIR A ATIVIDADE POR COMPLETO, 
           ex.printStackTrace();          //OU SEJA, PEGAR OS 3 POSTs, pegava somente 1
        }
        return item;
    }

   
    
    public Connection getConnection() {
        return this.conn;
    }
}

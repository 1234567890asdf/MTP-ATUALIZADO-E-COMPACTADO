
package aula28.pkg08java;

import java.awt.Frame;


public class Aula2808Java {

    
    public static void main(String[] args) {
        Frame frame = new Frame("Primeiro frame"); //titulo que aparecera em cima
        frame.setSize(500, 500); //tamanho
        frame.setVisible(true); //defini se a tela ira aparecer
        frame.setLocation(200, 150); //localização em que a tela ficara
      
    }
    
}
